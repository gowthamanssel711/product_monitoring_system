
class Device:
    def __init__(self,device):
        self.device = device

    def store_data(self):
        return "ok"