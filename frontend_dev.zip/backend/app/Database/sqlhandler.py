from Database.config import DBConfig
from mysql.connector import pooling
import datetime
import logging

db_logger = logging.getLogger('db_log')
db_logger.setLevel(logging.DEBUG)
file_handle = logging.FileHandler("/home/gowthaman/Documents/iot_dashboard/iot_dashboard/backend/app/Logs/server.log")
log_format = logging.Formatter('%(asctime)s %(levelname)s  : %(message)s')
file_handle.setFormatter(log_format)
db_logger.addHandler(file_handle)

configuration = DBConfig()

server = configuration.DB_SERVER
database = configuration.DB_NAME
user_name = configuration.DB_USER
password = configuration.DB_PASSWORD
port = configuration.DB_PORT
no_conn = configuration.CONNECTIONS



try:
    connection_pool = pooling.MySQLConnectionPool(pool_name = "mysqlconnectionpool",
                                                pool_reset_session = True,
                                                host=server,
                                                database=database,
                                                user=user_name,
                                                password=password,port=port,
                                                pool_size= no_conn)

    db_logger.debug(f"DB Connected")

except Exception as e:

    db_logger.critical(f"DB not connected {e}")


class DBHandler:

    def __init__(self) -> None:
        pass
    

    def get_connection(self):
        global connection_pool
        try:
            cnxn = connection_pool.get_connection()
            if (cnxn.is_connected):
                return cnxn
            else:
                db_logger.error(f"connection error {e}")
                return None
        except Exception as e:
            db_logger.error(f"connection error {e}")


    def fetch_db(self,query,data):

        try:          
            cnxn = self.get_connection()
            cursor = cnxn.cursor(buffered= True)
            cursor.execute(query,[])
            rows = cursor.fetchall()
            cnxn.commit()
            cursor.close()
            cnxn.close()
            return (1,rows)
        except Exception as e:
            return (0,e)

    def data_info(self,data):

        insert_query = 'INSERT INTO data_info (time, product, value,device) VALUES (%s, %s, %s, %s)'
        db_logger.debug(f"query to execute {insert_query}")
        try:
            cnxn = self.get_connection()
            cursor = cnxn.cursor(buffered= True)
            cursor.execute(insert_query,data)
            cnxn.commit()
            cursor.close()
            cnxn.close()
            db_logger.debug(f"inserted data {insert_query}  {data}")
            return 1
        except Exception as e:
            db_logger.error(f"insertion error {e}")
            return e

    def retreive_data(self,data):
        try:
            product = 'B'
            query = f"select time,product,value,device from data_info where product in ('{product}')"
            data = self.fetch_db(query,[])
            return data
        except Exception as e:
            db_logger.error(f"reterive error {e}")
            return (0,e)


    def instant_count(self,data):

        try:
            product = 'A'
            query = f"select value from data_info where product in ('{product}') order by value desc"
            data = self.fetch_db(query,[])

            return data
        except Exception as e:

            return (0,e)



# obj = DBHandler()
# obj.data_info([1659971137,'A',1,'device_1'])

