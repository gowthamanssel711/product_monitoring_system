import os
import inspect
import logging

class DBConfig(object):
    DB_SERVER = 'localhost'
    DB_NAME = 'iot'
    DB_USER = 'iot_user'
    DB_PASSWORD = 'iot_database@2022'
    DB_PORT = 6033
    CONNECTIONS = 30
    APP_PORT = 5000