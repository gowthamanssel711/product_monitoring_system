from flask import Flask,request,jsonify
from time import time
import logging
from datetime import datetime
from Database.config import DBConfig
from Database.sqlhandler import DBHandler
import json
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
data_handler = DBHandler()



@app.route('/get_product_list/',methods=['GET'])
def get_product_list():
    try:
        product_list = ['A','B','C','D','E','F']
        result = {
            'code' : 200,
            'data' : product_list
        }
        return jsonify(result)
    except Exception as e:
        result = {
            'code':400
        }
        return jsonify(result)

@app.route('/store_data/',methods=['POST'])
def store_data():
    try:
        epoch = datetime.now().strftime('%s')
        print(epoch)
        data_ = request.get_json()['data']
        data = [epoch].extend(data_)
        result = data_handler.data_info(data)
        logger.info(f"{request.remote_addr}   data received  {data}")
        return_data = {
            'code':200,
            'insert_status':result
        }
        return return_data
    except Exception as e:
        logger.error(f"data insert error {e}")
        return_data = {
            'code':400,
             'insert_status' : e
        }

        return return_data


@app.route('/get_main_data/',methods=['POST'])
def get_main_data():
    try:
        data = request.get_json()
        logger.info(f"{request.remote_addr}  reterive data -->   {data}")
        product_data = data_handler.retreive_data(data)
        data = []
        if(product_data[0] ==1 ):
            for row in product_data[1]:
                data.append(list(row))
            return_data = {
                'code' : 200,
                'data' : data
            }
            return jsonify(return_data)

    except Exception as e:
        return_data = {
            'code':400,
             'reteriv error' : e
        }

        return jsonify(return_data)  


@app.route('/get_instant_count/',methods=['POST'])
def get_instant_count():
    try:
        data = request.get_json()
        logger.info(f"{request.remote_addr}  reterive data -->   {data}")
        product_data = data_handler.instant_count(data)
        print(product_data)
        data = []
        if(product_data[0] ==1 ):
            count = product_data[1][0]
            return_data = {
                'code' : 200,
                'data' : count
            }
            return jsonify(return_data)

    except Exception as e:
        return_data = {
            'code':400,
             'reteriv error' : e
        }

        return jsonify(return_data)  

        

if __name__ == "__main__":

    global logger,error_logger

    logger = logging.getLogger('iot')
    logger.setLevel(logging.DEBUG)
    file_handle = logging.FileHandler("./Logs/server.log")
    log_format = logging.Formatter('%(asctime)s %(levelname)s  : %(message)s')
    file_handle.setFormatter(log_format)
    logger.addHandler(file_handle)

    error_logger = logging.getLogger('error_iot')
    error_logger.setLevel(logging.ERROR)
    file_handle = logging.FileHandler("./Logs/server_error.log")
    log_format = logging.Formatter('%(asctime)s %(levelname)s  : %(message)s')
    file_handle.setFormatter(log_format)
    error_logger.addHandler(file_handle)


    app.run(host='0.0.0.0',port=DBConfig.APP_PORT,debug= True)
