import * as React from 'react';

import Box from '@mui/material/Box';




export default function Devices() {
  

  return (
    <Box sx={{ flexGrow: 1 }}>
     <div className='App'> <h1> Devices </h1></div>   
    </Box>
  );
}
