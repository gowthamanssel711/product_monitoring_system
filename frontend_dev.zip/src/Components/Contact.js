
import * as React from 'react';

import Box from '@mui/material/Box';


export default function Contact() {
  

  return (
   <Box sx={{ flexGrow: 1 }}>
     <div className='App'> <h1> Contact </h1></div>   
    </Box>
  );
}
