import axios from "axios";
import { URL } from "./URL"


export function Get_Maindata(route,param){
    
    return new Promise((resolve,reject) => {
        const url = URL+route
        console.log(url)
        axios.post(url,param).then((response) => {
            if (response.data.code === 400){
                resolve(response.data.code);
                console.log(`${url} failed`);
            }
            else{
                console.log(`${url} success`);
                resolve(response.data);

            }
        }).catch((e)=>{
            console.log(`${url} ${e}`);
            reject(e);
        })
    })

}

export function Get_ProductList(route,param){
    
    return new Promise((resolve,reject) => {
        const url = URL+route
        console.log(url)
        axios.get(url).then((response) => {
            if (response.data.code === 400){
                resolve(response.data.code);
                console.log(`${url} failed`);
            }
            else{
                console.log(`${url} success`);
                resolve(response.data);

            }
        }).catch((e)=>{
            console.log(`${url} ${e}`);
            reject(e);
        })
    })

}



export function Get_InstantCount(route,param){
    
    return new Promise((resolve,reject) => {
        const url = URL+route
        axios.post(url,param).then((response) => {
            if (response.data.code === 400){
                resolve(response.data.code);
                console.log(`${url} failed`);
            }
            else{
                console.log(`${route} success`);
                resolve(response.data);

            }
        }).catch((e)=>{
            console.log(`${url} ${e}`);
            reject(e);
        })
    })

}