const URL = 'http://192.168.152.152:5000'

export {URL}