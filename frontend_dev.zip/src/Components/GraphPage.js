
import * as React from 'react';
import OverAllGraph from './Graph/OverAllgraph';

import Box from '@mui/material/Box';


export default function GraphPage() {
  

  return (
   <Box sx={{ flexGrow: 1 }}>
     <OverAllGraph/>  
    </Box>
  );
}
