
import * as React from 'react';

import Box from '@mui/material/Box';


export default function Default() {
  

  return (
   <Box sx={{ flexGrow: 1 }}>
     <div className='App'> <h1> Product Monitoring System </h1></div>   
    </Box>
  );
}
